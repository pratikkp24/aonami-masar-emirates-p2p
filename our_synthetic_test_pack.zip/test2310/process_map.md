# P2P process map
Synthetic sample for the prototype. Target times are in working hours from the moment a step starts; a working day is 8 hours.

## Create Position
| Step | Owner team | Approver | Target hours |
|---|---|---|---|
| HR Ops validation | HR Operations | HR operations specialist | 8 |
| Org design review | Org Design | Org design lead | 16 |
| Budget approval | Finance | Finance business partner | 16 |
| HRBP approval | HR Business Partners | HR business partner | 8 |
| System update | HRIS | HRIS administrator | 8 |

## Transfer
| Step | Owner team | Approver | Target hours |
|---|---|---|---|
| HR Ops validation | HR Operations | HR operations specialist | 8 |
| Releasing manager approval | Line Management | Current line manager | 16 |
| HRBP approval | HR Business Partners | HR business partner | 8 |
| Payroll impact check | Payroll | Payroll specialist (only when the cost centre changes) | 8 |
| System update | HRIS | HRIS administrator | 8 |

## Promotion
| Step | Owner team | Approver | Target hours |
|---|---|---|---|
| HR Ops validation | HR Operations | HR operations specialist | 8 |
| HRBP approval | HR Business Partners | HR business partner | 8 |
| Director approval | Directors | Department director (only for +2 grades or new grade G10 and above) | 16 |
| Compensation review | Compensation and Benefits | Reward specialist | 16 |
| System update | HRIS | HRIS administrator | 8 |

## End of Service
| Step | Owner team | Approver | Target hours |
|---|---|---|---|
| HR Ops validation | HR Operations | HR operations specialist | 8 |
| Position action decision | Org Design | Org design lead | 8 |
| Final settlement | Payroll | Payroll specialist | 24 |
| System update | HRIS | HRIS administrator | 8 |

## Delete Position
| Step | Owner team | Approver | Target hours |
|---|---|---|---|
| HR Ops validation | HR Operations | HR operations specialist | 8 |
| Org design review | Org Design | Org design lead | 16 |
| Budget approval | Finance | Finance business partner | 8 |
| System update | HRIS | HRIS administrator | 8 |

## Teams
HR Operations has two processing teams: HR Ops Central (positions at Dubai HQ) and HR Ops Airport (positions at Dubai Airport and the Dubai Engineering Centre).
A returned request goes back to the submitting manager and restarts at HR Ops validation when resubmitted.
