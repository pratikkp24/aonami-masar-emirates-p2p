# Validation rules
Synthetic sample for the prototype. Each request type must pass these checks before HR processes it.

| ID | Applies to | Rule | On failure |
|---|---|---|---|
| V01 | Create Position, Transfer, Promotion, Delete Position | The effective date is at least 14 calendar days after submission | Return: effective date too soon |
| V02 | End of Service | The last working day is at least 7 calendar days after submission | Return: last working day too soon |
| V03 | Transfer, Promotion, End of Service | The employee is the current incumbent of the stated current position | Return: employee not in stated position |
| V04 | Transfer | The target position exists, is active and is vacant | Return: target position not available |
| V05 | Transfer | The target position's grade is within one grade of the employee's current grade; larger changes are promotions | Return: grade change too large for a transfer |
| V06 | Transfer | The cost centre stated matches the target position's department | Return: cost centre does not match |
| V07 | Promotion | The new grade is one or two grades above the current grade | Return: invalid grade change |
| V08 | Promotion | A justification of at least 40 characters is provided | Return: justification missing |
| V09 | Promotion | The effective date is the first day of a month | Return: effective date must be the 1st |
| V10 | Promotion | Promotions of two grades, or to grade G10 or above, need director approval | Routing: add director approval |
| V11 | Create Position | A budget reference in the form BR-YYYY-NNNN is provided | Return: budget reference missing |
| V12 | Create Position | The job code exists and the grade is within the job's band | Return: grade outside job band |
| V13 | Create Position | The reports-to position exists and is active | Return: reports-to position invalid |
| V14 | Create Position | A role profile is attached | Return: role profile missing |
| V15 | End of Service | A position action is chosen: Freeze, Delete or Backfill | Return: position action missing |
| V16 | End of Service, Transfer, Promotion | No other request is open for the same employee | Hold: dependent transaction open |
| V17 | Delete Position | The position is vacant | Return: position not vacant |
| V18 | Delete Position | No active position reports to it | Return: position has direct reports |
| V19 | Delete Position, Transfer | No other request is open for the same position | Hold: dependent transaction open |
